package pkgPosNeg;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Shreyas
 */
@WebService(serviceName = "NewWebService")
public class NewWebService {
    @WebMethod(operationName="NewWebService")
    public String NewWebService(@WebParam(name="number1") int num)
    {
        if (num>0)
        {
            return "Number is positive";
        }
        else
        {
            return "Number is negative";
        }
    }
}
