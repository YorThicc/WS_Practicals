package pkgStatefull;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author admin
 */
@WebService(serviceName = "NewWebService")
public class NewWebService {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "average")
public String average(@WebParam(name = "name") String numbers) {
String[] stringArray=numbers.split("\\s");
int[] intArray= new int[stringArray.length];
for(int i=0;i<stringArray.length;i++) {
String numberAsstring =stringArray[i];
intArray[i]= Integer.parseInt(numberAsstring); }
int sum=0;
for(int i=0;i<intArray.length;i++) {
sum=sum+intArray[i]; }
return "Sum of " +intArray.length+ " no is" +" "+sum+ " and average is " +sum/intArray.length;
}}
