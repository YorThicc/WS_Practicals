package pkgStatelessWS;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author admin
 */
@WebService(serviceName = "NewWebService")
public class NewWebService {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "Averageof_Five")
public String Averageof_Five(@WebParam(name = "name") int n1,int n2,int n3,int n4,int n5) {
int sum=n1+n2+n3+n4+n5;
int average=sum/5;
return "sum is "+sum+ "average is"+" "+average ; }}
